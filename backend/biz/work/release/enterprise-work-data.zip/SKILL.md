---
name: enterprise-work-data
description: 可追溯的数据分析和表格交付
---
# 数据工作
先检查工作表、列名、单位、时间范围、缺失值、重复值和样本量，记录来源文件与工作表。确认业务口径后计算，不把空值当作零。对汇总值、行数和至少一个代表性样本做独立核验。
使用已有 Python/openpyxl 等本地工具保留原始数据，公式和原始列应可追踪。图表注明单位与筛选条件。保存可编辑 xlsx 与分析说明，并重新打开验证文件结构、公式、合计和异常值。无法在当前环境重算的公式须明确标记，禁止将缓存值视为已重算。正式文件放在 /workspace/.jingjiaagent/output。

环境中预装 /opt/jingjiaagent/skills/data-analysis、report-writing、presentation、deliverable-check，按任务查阅其中确定性检查脚本与模板；不需要联网安装。平台负责正式保存后的转换和渲染，不在 Guest 中暴露内部转换服务令牌。

Office Python 工具和脚本统一用 `/opt/office/venv/bin/python` 调用。Shell 可能重置 PATH，请保持这个绝对解释器路径；不要依赖 `python` 或 `python3` 别名，也无需联网安装依赖。

PDF 表格使用 /opt/office/venv/bin/python /opt/jingjiaagent/skills/report-writing/scripts/pdf_tools.py tables <实际附件路径> --output /workspace/.jingjiaagent/work/pdf-tables.xlsx，也支持 .csv。保留 source_file、source_page、source_table、source_row 追溯列，核对表头、合并单元格与关键数值后再计算。单文件限 32 MiB、200 页；输出不能覆盖已有文件，重跑换新名称。扫描件、空结果与无法识别的表格明确说明，当前不提供 OCR，不编造内容。详细处理流程见 /opt/jingjiaagent/skills/data-analysis/SKILL.md。
本地 HTML 可用 beautifulsoup4/lxml 读取，YAML 用 yaml.safe_load。requests 仅用于现有规则允许且用户已授权的接口，不扩大网络权限或安装依赖。

文字和表格提取允许读取表单 PDF 的页面内容，但不保证取得交互字段值，需核对用户已填写的数据；含 AcroForm 字段或 XFA 的文件不能直接使用该工具抽页或合并，处理方法见 /opt/jingjiaagent/skills/report-writing/SKILL.md。
