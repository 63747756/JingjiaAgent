---
name: enterprise-work-presentation
description: 资料驱动的可编辑演示文稿
---
# 演示工作
确认演示对象、用途、时长和页数。先用来源材料形成每页主题与论据，数字、图表和引用须追溯到输入；缺失资料标明待补。每页围绕一个主题，保持字体、配色、单位和页码一致。
使用已安装的演示工具生成可编辑 pptx，避免用整页图片代替需要编辑的正文。生成后重新打开核对页数、文本与图表结构，将正式文件放入 /workspace/.jingjiaagent/output；平台在保存队列中转换 PDF 并核验预览。检查状态出来前说明等待平台验证，不声称已通过版面检查。不得直接连接内部转换服务或索取其令牌。

环境中预装 /opt/jingjiaagent/skills/data-analysis、report-writing、presentation、deliverable-check，按任务查阅其中确定性检查脚本与模板；不需要联网安装。平台负责正式保存后的转换和渲染，不在 Guest 中暴露内部转换服务令牌。

Office Python 工具和脚本统一用 `/opt/office/venv/bin/python` 调用。Shell 可能重置 PATH，请保持这个绝对解释器路径；不要依赖 `python` 或 `python3` 别名，也无需联网安装依赖。

修改员工提供的 PPTX 时，先运行 /opt/office/venv/bin/python /opt/jingjiaagent/skills/presentation/scripts/inspect_deck.py <实际附件路径> --output /workspace/.jingjiaagent/work/deck-inspection.json，可用 --slide 2 指定第 2 页。slide_number 从 1 开始，shape_path 是从 0 开始的各层 shapes 索引，结合 shape_id 和名称定位对象。
用预装 python-pptx 修改普通文本、表格等受支持对象，尽量修改原 paragraph.runs 以保留样式；脚本放入 /workspace/.jingjiaagent/work，另存为 /workspace/.jingjiaagent/output 下的新 PPTX，不能覆盖原件。修改前后核对非目标内容，SmartArt、复杂动画、嵌入对象不保证可编辑或完全保真，不宣称无损编辑。检查脚本限制 PPTX 64 MiB、展开内容 256 MiB、500 页。后端转换后还要核对版面，完整流程见 /opt/jingjiaagent/skills/presentation/SKILL.md。

遇到不支持的形状或图表，对应 type 标为 UNSUPPORTED，形状的 warnings 说明内容未完整解析，保留页码、shape_path、shape_id、名称和尺寸，其余普通内容继续检查。不能将告警对象当作完整读取；损坏的文件关系、XML、无效图表参数或容量超限仍会报错。
