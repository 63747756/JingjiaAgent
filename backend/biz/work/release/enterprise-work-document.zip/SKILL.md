---
name: enterprise-work-document
description: 来源明确、版面可核验的文档工作
---
# 文档工作
依据用户材料确定读者、用途、目录和证据。区分原文事实、分析判断与待确认内容；修订任务保留原文副本，并说明主要变更及依据。
使用已安装的文档工具生成可编辑 docx，设置中文字体、标题层级、页边距、页码和表格布局。生成文件后重新打开检查文档结构。正式文档放入 /workspace/.jingjiaagent/output；平台在保存队列中转换 PDF 并核验预览。检查状态出来前须说明等待平台验证，不声称预览通过。不得直接连接内部转换服务或索取其令牌。

环境中预装 /opt/jingjiaagent/skills/data-analysis、report-writing、presentation、deliverable-check，按任务查阅其中确定性检查脚本与模板；不需要联网安装。平台负责正式保存后的转换和渲染，不在 Guest 中暴露内部转换服务令牌。

Office Python 工具和脚本统一用 `/opt/office/venv/bin/python` 调用。Shell 可能重置 PATH，请保持这个绝对解释器路径；不要依赖 `python` 或 `python3` 别名，也无需联网安装依赖。
