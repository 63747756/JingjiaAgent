---
name: enterprise-work-document
description: 来源明确、版面可核验的文档工作
---
# 文档工作
依据用户材料确定读者、用途、目录和证据。区分原文事实、分析判断与待确认内容；修订任务保留原文副本，并说明主要变更及依据。
使用已安装的文档工具生成可编辑 docx，设置中文字体、标题层级、页边距、页码和表格布局。生成文件后重新打开检查文档结构。正式文档放入 /workspace/.jingjiaagent/output；平台在保存队列中转换 PDF 并核验预览。检查状态出来前须说明等待平台验证，不声称预览通过。不得直接连接内部转换服务或索取其令牌。

环境中预装 /opt/jingjiaagent/skills/data-analysis、report-writing、presentation、deliverable-check，按任务查阅其中确定性检查脚本与模板；不需要联网安装。平台负责正式保存后的转换和渲染，不在 Guest 中暴露内部转换服务令牌。

Office Python 工具和脚本统一用 `/opt/office/venv/bin/python` 调用。Shell 可能重置 PATH，请保持这个绝对解释器路径；不要依赖 `python` 或 `python3` 别名，也无需联网安装依赖。

PDF 资料使用 /opt/office/venv/bin/python /opt/jingjiaagent/skills/report-writing/scripts/pdf_tools.py text <实际附件路径> --output /workspace/.jingjiaagent/work/pdf-text.json，逐页保留原文件和页码；纯文本输出使用 --format text。表格使用 tables 子命令输出 .xlsx 或 .csv；按页提取使用 extract <实际附件路径> --pages 1,3-5 --output /workspace/.jingjiaagent/output/extracted.pdf；合并使用 merge <实际附件路径1> <实际附件路径2> --output /workspace/.jingjiaagent/output/merged.pdf。
单文件及输出限 32 MiB、200 页，合并输入总量也不得超过 32 MiB、200 页，拒绝覆盖已有输出。保留原件，关键文字、顺序和表格仍需回到来源核对；疑似扫描页、没有文字层或提取失败时说明限制，当前没有 OCR。完整命令和处理边界见 /opt/jingjiaagent/skills/report-writing/SKILL.md。
本地 HTML 可用 beautifulsoup4/lxml 读取，YAML 用 yaml.safe_load。requests 仅用于现有规则允许且用户已授权的接口，不扩大网络权限或安装依赖。

extract 和 merge 拒绝含 AcroForm 字段或 XFA 的表单 PDF，避免生成丢失表单字段的文件。需要抽页或合并时，先让用户另存或打印为普通 PDF 副本，并核对填写内容已显示完整；不能覆盖原表单。text 和 tables 仍可提取表单 PDF 的页面内容，但不保证读取所有交互字段。
